If run locally, must be run using --allow-file-access-from-files 


In OSX ( within the directory , with kiosk mode ):
"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" --allow-file-access-from-files  --args -kiosk index.html


In Windows:
?????? ( although I bet it is similar :) )
