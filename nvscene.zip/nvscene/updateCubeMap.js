function updateCubeMap(){

 /*if( !cubeMapRendered ){

     gem.body.visible = false; // *cough*

      cubeCamera.updateCubeMap( renderer, scene );

      gem.body.visible = true;
      //  var reflectionCube = THREE.ImageUtils.loadTextureCube( urls );
      //reflectionCube.format = THREE.RGBFormat;

  
     // cubeMapRendered = true;

     for( var i = 0; i < cubeMapSpheres.length; i++ ){


        scene.remove( cubeMapSpheres[i] );


      }

    }*/



}
